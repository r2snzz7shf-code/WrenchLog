# WrenchLog Cloud Starter

Dark, mobile-friendly WrenchLog prototype with Supabase email/password authentication and cloud-saved cars and records.

## Files
- `index.html` — responsive UI and application logic
- `config.js` — Supabase project URL and public client key placeholders
- `schema.sql` — database tables and Row Level Security policies
- `manifest.webmanifest` — basic installable-web-app metadata

## Free setup: Supabase + GitHub Pages

### 1. Create the Supabase project
1. Create a free project at https://supabase.com/.
2. In the project dashboard, open **SQL Editor**.
3. Open `schema.sql` from this repository, copy the full contents, paste into SQL Editor, and run it.
4. Open **Project Settings → API** (the location/name may vary in the dashboard).
5. Copy the **Project URL** and the public **publishable key** or legacy **anon key**.

Never use the `service_role` key in frontend code. It is secret and bypasses Row Level Security.

### 2. Configure the frontend
1. Open `config.js` in GitHub and choose Edit.
2. Replace `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE` with the Project URL.
3. Replace `PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE` with the public publishable/anon key.
4. Commit the changes.

The public key is designed for client use only when Row Level Security is enabled and correct policies are in place. The SQL script configures ownership policies for cars and their records.

### 3. Set up email authentication
1. In Supabase, open **Authentication → URL Configuration**.
2. Set the Site URL to the deployed GitHub Pages URL once you have it.
3. Add the same deployed URL to the Redirect URLs allowlist if requested.
4. For easier first testing, use the dashboard's email-confirmation settings intentionally. If email confirmation is enabled, new users must click the confirmation link before signing in. Configure the redirect URL to return to your deployed app.

### 4. Publish on GitHub Pages
1. Create a GitHub repository named `wrenchlog`.
2. Upload `index.html`, `config.js`, `schema.sql`, `manifest.webmanifest`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for the GitHub Pages URL to appear.
6. Put that URL into Supabase's Site URL and Redirect URLs.

### 5. Test before sharing
- Create a test account and sign in.
- Add a vehicle, maintenance record, build record, and expense.
- Refresh the page and verify the records remain.
- Create a second test account and verify it cannot see the first account's data.
- Test on your iPhone and desktop.

## Current scope and limitations
- Email/password sign-up and sign-in
- Cloud-saved vehicle profiles
- Cloud-saved maintenance, build, and expense records
- Per-user access controls through Supabase RLS
- Dark, responsive layout
- Basic install metadata for adding to a phone's Home Screen

Not included yet: password reset flow, photo/receipt uploads, mileage-based push notifications, export/import, subscription billing, native App Store packaging, or professional vehicle-specific maintenance schedules. Add those after the core app is tested.

## Important
This is a starter project. Review security and privacy requirements before collecting real customer data. Do not enter sensitive information beyond what's needed for the app.
