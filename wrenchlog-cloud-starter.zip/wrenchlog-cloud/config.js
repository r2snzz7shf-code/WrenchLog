/*
  WrenchLog public client configuration.
  Replace these placeholders with your Supabase Project URL and publishable/anon key.
  This file is safe to commit only with the public anon/publishable key and proper RLS policies.
  NEVER put a Supabase service_role key or other secret in browser code.
*/
window.WRENCHLOG_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE"
};
