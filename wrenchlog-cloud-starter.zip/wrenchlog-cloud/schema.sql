-- WrenchLog database setup for Supabase.
-- Run this entire script in Supabase Dashboard -> SQL Editor.
-- Row Level Security ensures users can access only their own cars and records.

create extension if not exists pgcrypto;

create table if not exists public.cars (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  year integer not null check (year >= 1886 and year <= 2100),
  make text not null,
  model text not null,
  engine text,
  mileage bigint not null default 0 check (mileage >= 0),
  nickname text,
  created_at timestamptz not null default now()
);

create table if not exists public.records (
  id uuid primary key default gen_random_uuid(),
  car_id uuid not null references public.cars(id) on delete cascade,
  type text not null check (type in ('maintenance','build','expense')),
  date date not null default current_date,
  title text not null,
  cost numeric(12,2) not null default 0 check (cost >= 0),
  mileage bigint check (mileage is null or mileage >= 0),
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists cars_user_id_idx on public.cars(user_id);
create index if not exists records_car_id_idx on public.records(car_id);
create index if not exists records_date_idx on public.records(date desc);

alter table public.cars enable row level security;
alter table public.records enable row level security;

drop policy if exists "Users can view their own cars" on public.cars;
create policy "Users can view their own cars" on public.cars
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "Users can add their own cars" on public.cars;
create policy "Users can add their own cars" on public.cars
  for insert to authenticated with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update their own cars" on public.cars;
create policy "Users can update their own cars" on public.cars
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users can delete their own cars" on public.cars;
create policy "Users can delete their own cars" on public.cars
  for delete to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "Users can view records for their own cars" on public.records;
create policy "Users can view records for their own cars" on public.records
  for select to authenticated using (
    exists (select 1 from public.cars c where c.id = records.car_id and c.user_id = (select auth.uid()))
  );

drop policy if exists "Users can add records to their own cars" on public.records;
create policy "Users can add records to their own cars" on public.records
  for insert to authenticated with check (
    exists (select 1 from public.cars c where c.id = records.car_id and c.user_id = (select auth.uid()))
  );

drop policy if exists "Users can update records for their own cars" on public.records;
create policy "Users can update records for their own cars" on public.records
  for update to authenticated using (
    exists (select 1 from public.cars c where c.id = records.car_id and c.user_id = (select auth.uid()))
  ) with check (
    exists (select 1 from public.cars c where c.id = records.car_id and c.user_id = (select auth.uid()))
  );

drop policy if exists "Users can delete records for their own cars" on public.records;
create policy "Users can delete records for their own cars" on public.records
  for delete to authenticated using (
    exists (select 1 from public.cars c where c.id = records.car_id and c.user_id = (select auth.uid()))
  );

-- Helpful for API access in a standard Supabase project:
grant usage on schema public to authenticated;
grant select, insert, update, delete on public.cars to authenticated;
grant select, insert, update, delete on public.records to authenticated;
